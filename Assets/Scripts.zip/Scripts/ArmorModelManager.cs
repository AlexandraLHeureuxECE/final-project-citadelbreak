using UnityEngine;

public class ArmorModelManager : MonoBehaviour
{
    public static ArmorModelManager instance;

    void Awake()
    {
        instance = this;
    }

    public void ActivateArmorSet(string setName)
    {
        foreach (Transform child in transform)
        {
            bool match = child.name.Contains(setName);
            child.gameObject.SetActive(match);

            if (match)
            {
                // 🔁 Force "reload" the Animator by toggling it off and on
                Animator animator = child.GetComponent<Animator>();
                if (animator != null)
                {
                    animator.enabled = false;
                    animator.enabled = true;
                    Debug.Log("🔄 Reloaded Animator on: " + child.name);
                }
            }
        }
    }
}